import os, threading, time, csv, json
from datetime import datetime
from flask import Flask, render_template, request, jsonify, Response
from flask_socketio import SocketIO
from werkzeug.utils import secure_filename
from src.engine import DetectionEngine, normalize_row, train_or_load
from src.sensor import LiveSensor

app=Flask(__name__)
app.config["SECRET_KEY"]="sentinelai-local-dev"
app.config["UPLOAD_FOLDER"]="uploads"
app.config["MAX_CONTENT_LENGTH"]=100*1024*1024
socketio=SocketIO(app,cors_allowed_origins=[],async_mode="threading")
os.makedirs(app.config["UPLOAD_FOLDER"],exist_ok=True)
engine=train_or_load()
sensor=LiveSensor(engine, socketio)
events=[]
events_lock=threading.Lock()
state={"mode":"idle","running":False,"source":"none","started":None,"processed":0,"alerts":0,"last_event":None}
MAX_EVENTS=1200

def publish_event(event):
    with events_lock:
        events.insert(0,event)
        del events[MAX_EVENTS:]
        state["processed"]+=1
        if event["is_alert"]: state["alerts"]+=1
        state["last_event"]=event["timestamp"]
    socketio.emit("new_event",event)
    socketio.emit("stats",get_stats())

def get_stats():
    with events_lock:
        arr=list(events)
    sev={k:sum(1 for e in arr if e["severity"]==k) for k in ["Critical","High","Medium","Low"]}
    return {"running":state["running"],"mode":state["mode"],"source":state["source"],"processed":state["processed"],"alerts":state["alerts"],"critical":sev["Critical"],"high":sev["High"],"medium":sev["Medium"],"low":sev["Low"],"last_event":state["last_event"],"recent":arr[:8]}

engine.set_callback(publish_event)

@app.route("/")
def index(): return render_template("index.html")
@app.route("/replay")
def replay_page(): return render_template("replay.html")
@app.route("/live")
def live_page(): return render_template("live.html")
@app.route("/events")
def events_page(): return render_template("events.html")
@app.route("/models")
def models_page(): return render_template("models.html")
@app.route("/api/stats")
def api_stats(): return jsonify(get_stats())
@app.route("/api/events")
def api_events():
    with events_lock: return jsonify(events[:500])
@app.route("/api/interfaces")
def api_interfaces():
    return jsonify({"interfaces":sensor.interfaces(),"available":sensor.available()})
@app.route("/api/live/start",methods=["POST"])
def live_start():
    data=request.get_json(silent=True) or {}
    interface=data.get("interface") or None
    try:
        sensor.start(interface)
        state.update(mode="live",running=True,source=interface or "default interface",started=datetime.now().isoformat())
        socketio.emit("status",get_stats())
        return jsonify({"ok":True,"message":"Live capture started","stats":get_stats()})
    except Exception as e:
        return jsonify({"error":str(e)}),400
@app.route("/api/live/stop",methods=["POST"])
def live_stop():
    sensor.stop()
    state.update(running=False,mode="idle")
    socketio.emit("status",get_stats())
    return jsonify({"ok":True,"stats":get_stats()})
@app.route("/api/replay/upload",methods=["POST"])
def replay_upload():
    f=request.files.get("file")
    if not f or not f.filename: return jsonify({"error":"Choose a CSV file."}),400
    if not f.filename.lower().endswith(".csv"): return jsonify({"error":"Only CSV files are supported."}),400
    name=secure_filename(f.filename)
    path=os.path.join(app.config["UPLOAD_FOLDER"],name)
    f.save(path)
    try:
        with open(path,newline="",encoding="utf-8-sig",errors="replace") as fp:
            reader=csv.DictReader(fp)
            headers=reader.fieldnames or []
            if not headers: raise ValueError("CSV needs a header row.")
            # Validate and cache rows; replay worker reads normalized features.
            rows=list(reader)
        if not rows: raise ValueError("CSV contains no data rows.")
        return jsonify({"ok":True,"filename":name,"rows":len(rows),"headers":headers,"message":"CSV ready for replay"})
    except Exception as e: return jsonify({"error":str(e)}),400
@app.route("/api/replay/start",methods=["POST"])
def replay_start():
    data=request.get_json(silent=True) or {}
    name=secure_filename(data.get("filename",""))
    speed=max(.05,min(float(data.get("speed",5)),100))
    path=os.path.join(app.config["UPLOAD_FOLDER"],name)
    if not name or not os.path.isfile(path): return jsonify({"error":"Upload a CSV first."}),400
    if state["running"]: return jsonify({"error":"Stop the current capture/replay before starting another."}),400
    threading.Thread(target=replay_worker,args=(path,speed),daemon=True).start()
    state.update(mode="replay",running=True,source=name,started=datetime.now().isoformat())
    socketio.emit("status",get_stats())
    return jsonify({"ok":True,"message":"Replay started","stats":get_stats()})
def replay_worker(path,speed):
    try:
        with open(path,newline="",encoding="utf-8-sig",errors="replace") as fp:
            reader=csv.DictReader(fp)
            for row in reader:
                if not state["running"] or state["mode"]!="replay": break
                engine.process(normalize_row(row),source="dataset replay")
                time.sleep(1.0/speed)
    finally:
        if state["mode"]=="replay":
            state.update(running=False,mode="idle")
            socketio.emit("status",get_stats())
@app.route("/api/demo/start",methods=["POST"])
def demo_start():
    if state["running"]: return jsonify({"error":"Stop the current stream first."}),400
    threading.Thread(target=demo_worker,daemon=True).start()
    state.update(mode="demo",running=True,source="generated test flows",started=datetime.now().isoformat())
    return jsonify({"ok":True,"message":"Synthetic demo stream started"})
def demo_worker():
    import random
    while state["running"] and state["mode"]=="demo":
        row={"duration":random.uniform(1,15000),"protocol":random.choice([6,17,1]),"src_bytes":random.randint(20,200000),"dst_bytes":random.randint(0,180000),"src_packets":random.randint(1,300),"dst_packets":random.randint(0,300),"dst_port":random.choice([53,80,443,22,3389,8080,random.randint(1024,65535)]),"flow_rate":random.uniform(1,9000)}
        engine.process(row,source="synthetic demo")
        time.sleep(.8)
@app.route("/api/report")
def report():
    with events_lock: arr=list(events)
    payload={"generated_at":datetime.now().isoformat(),"disclaimer":"Events are model outputs. Anomaly flags are not proof of malicious activity.","summary":get_stats(),"events":arr}
    return Response(json.dumps(payload,indent=2),mimetype="application/json",headers={"Content-Disposition":"attachment; filename=sentinelai-report.json"})
if __name__=="__main__":
    socketio.run(app,host="127.0.0.1",port=5000,debug=False,allow_unsafe_werkzeug=True)
