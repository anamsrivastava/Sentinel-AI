import threading
class LiveSensor:
    def __init__(self,engine,socketio):
        self.engine=engine; self.socketio=socketio; self.sniffer=None; self.thread=None
    def available(self):
        try:
            import scapy.all
            return True
        except Exception:return False
    def interfaces(self):
        try:
            from scapy.all import get_if_list
            return get_if_list()
        except Exception:return []
    def start(self,interface=None):
        if not self.available():
            raise RuntimeError("Scapy is not installed. Install requirements and restart.")
        if self.thread and self.thread.is_alive():
            raise RuntimeError("Sensor is already running.")
        try:
            from scapy.all import sniff, IP, TCP, UDP, ICMP
        except Exception as e: raise RuntimeError(str(e))
        def on_packet(pkt):
            if IP not in pkt:return
            ip=pkt[IP]; proto=int(ip.proto)
            tcp=pkt.haslayer(TCP); udp=pkt.haslayer(UDP)
            sport=int(pkt[TCP].sport if tcp else pkt[UDP].sport if udp else 0)
            dport=int(pkt[TCP].dport if tcp else pkt[UDP].dport if udp else 0)
            length=len(pkt)
            row={"duration":0.01,"protocol":proto,"src_bytes":length,"dst_bytes":length,"src_packets":1,"dst_packets":1,"dst_port":dport,"flow_rate":length,"src_ip":ip.src,"dst_ip":ip.dst}
            self.engine.process(row,source="live packet sensor")
        def run():
            try:
                sniff(iface=interface,prn=on_packet,store=False,stop_filter=lambda p: self.sniffer is None)
            except Exception as e:
                self.socketio.emit("sensor_error",{"error":str(e)})
        self.sniffer=True
        self.thread=threading.Thread(target=run,daemon=True); self.thread.start()
    def stop(self):
        # Scapy sniff may not unblock immediately; timeout limits stop latency.
        self.sniffer=None
