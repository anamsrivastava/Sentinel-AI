import os, joblib, numpy as np
from datetime import datetime
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

FEATURES=["duration","protocol","src_bytes","dst_bytes","src_packets","dst_packets","dst_port","flow_rate"]
def normalize_row(row):
    aliases={"flow duration":"duration","flow_duration":"duration","protocol_type":"protocol","total_fwd_packets":"src_packets","total_backward_packets":"dst_packets","totlen_fwd_pkts":"src_bytes","totlen_bwd_pkts":"dst_bytes","destination port":"dst_port","destination_port":"dst_port","flow bytes/s":"flow_rate","flow_byts/s":"flow_rate","src_bytes":"src_bytes","dst_bytes":"dst_bytes"}
    cleaned={}
    for k,v in row.items():
        key=str(k).strip().lower()
        key=aliases.get(key,key.replace(" ","_"))
        if key in FEATURES:
            try:
                n=float(str(v).strip())
                if np.isfinite(n): cleaned[key]=n
            except: pass
    # Fallback: map arbitrary CSV numeric columns to feature slots in their existing order.
    if len(cleaned)<3:
        nums=[]
        for v in row.values():
            try:
                n=float(str(v).strip())
                if np.isfinite(n): nums.append(n)
            except: pass
        for i,k in enumerate(FEATURES):
            if k not in cleaned and i<len(nums): cleaned[k]=nums[i]
    defaults={"duration":0,"protocol":6,"src_bytes":0,"dst_bytes":0,"src_packets":1,"dst_packets":1,"dst_port":0,"flow_rate":0}
    defaults.update(cleaned)
    return defaults

class DetectionEngine:
    def __init__(self, anomaly, classifier, callback=None):
        self.anomaly=anomaly; self.classifier=classifier; self.callback=callback
    def set_callback(self,callback): self.callback=callback
    def process(self,row,source="unknown"):
        x=np.array([[float(row.get(k,0)) for k in FEATURES]],dtype=float)
        pred=int(self.anomaly.predict(x)[0])
        anomaly_score=float(-self.anomaly.decision_function(x)[0])
        label=str(self.classifier.predict(x)[0])
        probs=self.classifier.predict_proba(x)[0]
        confidence=float(max(probs))
        # Calibrated-looking risk is explicitly an estimated heuristic, not probability.
        risk=int(max(0,min(100,round(50+anomaly_score*35 if pred==-1 else 15+anomaly_score*20))))
        is_alert=(pred==-1 or label!="BENIGN")
        if risk>=85: severity="Critical"
        elif risk>=65: severity="High"
        elif risk>=40: severity="Medium"
        else: severity="Low"
        event={"id":datetime.now().strftime("EV-%H%M%S-")+str(np.random.randint(100,999)),"timestamp":datetime.now().strftime("%Y-%m-%d %H:%M:%S"),"source":source,"src_ip":row.get("src_ip","n/a"),"dst_ip":row.get("dst_ip","n/a"),"protocol":str(row.get("protocol","n/a")),"dst_port":row.get("dst_port",0),"classification":label,"anomaly":pred==-1,"risk":risk,"confidence":round(confidence*100,1),"severity":severity,"is_alert":is_alert,"features":{k:round(float(row.get(k,0)),3) for k in FEATURES}}
        if self.callback:self.callback(event)
        return event

def train_or_load():
    os.makedirs("models",exist_ok=True)
    anomaly_path="models/isolation_forest.joblib"; clf_path="models/random_forest.joblib"
    if os.path.exists(anomaly_path) and os.path.exists(clf_path):
        return DetectionEngine(joblib.load(anomaly_path),joblib.load(clf_path))
    # Reproducible, small synthetic training baseline. Replace with real labeled dataset for research-grade results.
    rng=np.random.default_rng(42)
    n=7000
    X=np.column_stack([rng.gamma(2,120,n),rng.choice([1,6,17],n),rng.lognormal(7,1.4,n),rng.lognormal(6.5,1.5,n),rng.poisson(18,n)+1,rng.poisson(15,n)+1,rng.choice([53,80,443,22,8080,3389,random_port()],n),rng.lognormal(4,1.2,n)])
    y=np.full(n,"BENIGN",dtype=object)
    # Synthetic attack patterns used only as a runnable starter baseline.
    for label,idx in [("PORT_SCAN",slice(0,450)),("DOS",slice(450,900)),("BRUTE_FORCE",slice(900,1250))]:
        y[idx]=label
    X[:450,6]=rng.integers(1,1024,450); X[:450,4]=rng.integers(80,800,450); X[:450,7]=rng.uniform(1000,15000,450)
    X[450:900,2]=rng.uniform(1e6,8e6,450); X[450:900,7]=rng.uniform(20000,90000,450); X[450:900,0]=rng.uniform(0,30,450)
    X[900:1250,6]=22; X[900:1250,4]=rng.integers(20,400,350); X[900:1250,7]=rng.uniform(200,5000,350)
    clf=Pipeline([("scale",StandardScaler()),("rf",RandomForestClassifier(n_estimators=120,class_weight="balanced",random_state=42,n_jobs=-1))])
    clf.fit(X,y)
    anomaly=Pipeline([("scale",StandardScaler()),("iforest",IsolationForest(n_estimators=150,contamination=.07,random_state=42,n_jobs=-1))])
    anomaly.fit(X)
    joblib.dump(anomaly,anomaly_path); joblib.dump(clf,clf_path)
    return DetectionEngine(anomaly,clf)
def random_port():
    return 49152
