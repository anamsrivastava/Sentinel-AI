# SentinelAI Realtime — Network Threat Analytics

A locally run academic prototype with a Flask-SocketIO live dashboard, CSV replay, a scikit-learn classifier + anomaly detector, event history, and JSON export.

## Setup
- Python 3.10–3.12 recommended.
- Windows: install Npcap from https://npcap.com/ for packet capture, then open terminal as Administrator for live capture. On Linux/macOS, packet capture may require elevated permissions and suitable capture support.
- Create a virtual environment, then:
  `pip install -r requirements.txt`
- Run: `python app.py`
- Open: http://127.0.0.1:5000

## Features
- Live packet capture via Scapy (best-effort; captures packets visible to selected interface; packet-to-flow feature mapping is simplified).
- Dataset CSV replay with adjustable speed.
- Live dashboard via Socket.IO.
- Isolation Forest + Random Forest pipelines; model files are trained and cached on first startup using synthetic data.
- Searchable event stream and JSON export.

## Critical limitations / responsible use
- Only capture traffic on devices/networks you own or are explicitly authorized to monitor.
- This is a student prototype, not a production IDS. Packet-level values are mapped to simplified flow features; detection output can be noisy and is not proof of compromise.
- The included models are trained on synthetic examples so the app is runnable. They are NOT trained on CIC-IDS2017/UNSW-NB15, and metrics must not be represented as validated benchmark results. Replace the training routine with a properly cleaned, split, and evaluated labeled dataset before research claims.
- Do not expose this development server publicly. It is bound to localhost.
- Live capture may require Administrator/root privileges and platform-specific packet capture drivers.
